"""Request bodies. Every field is bounded and unknown fields are rejected."""

from datetime import datetime
from typing import Annotated, Literal

from pydantic import AfterValidator, BaseModel, ConfigDict, Field

Money = Annotated[float, Field(ge=0, le=1e13, allow_inf_nan=False)]
Count = Annotated[float, Field(ge=0, le=1e9, allow_inf_nan=False)]
Pct = Annotated[float, Field(ge=0, le=100, allow_inf_nan=False)]


def _clean_text(value: str) -> str:
    # Strip control characters (other than newline/tab) that have no business
    # in names and labels and are a common vehicle for log/terminal tricks.
    return "".join(ch for ch in value if ch in "\n\t" or ch.isprintable()).strip()


def clean_str(max_len: int, min_len: int = 1):
    return Annotated[str, Field(min_length=min_len, max_length=max_len), AfterValidator(_clean_text)]


class Strict(BaseModel):
    model_config = ConfigDict(extra="forbid", str_strip_whitespace=True)


class SnapshotIn(Strict):
    period_label: clean_str(40)
    period_days: Annotated[int, Field(ge=1, le=366)] = 30
    revenue: Money
    cogs: Money = 0
    returns: Money = 0
    operating_expenses: Money = 0
    orders: Count = 0
    cash_on_hand: Money = 0
    monthly_burn: Money | None = None
    on_time_deliveries: Count = 0
    total_deliveries: Count = 0
    marketing_spend: Money = 0
    new_customers: Count = 0
    customers_lost: Count = 0
    total_customers: Count = 0
    accounts_receivable: Money = 0
    fixed_costs: Money = 0
    employees: Count = 0
    utilization_pct: Pct | None = None


class SkuIn(Strict):
    code: Annotated[str, Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9._\-/]+$")]
    name: clean_str(160)
    stock_on_hand: Count
    daily_sales: Count
    lead_time_days: Annotated[float, Field(ge=0, le=730, allow_inf_nan=False)]
    unit_cost: Money


class SkuBatch(Strict):
    items: Annotated[list[SkuIn], Field(max_length=5000)]
    replace: bool = False  # True = anything not listed is removed


class ShipmentIn(Strict):
    reference: Annotated[str, Field(min_length=1, max_length=64, pattern=r"^[A-Za-z0-9._\-/]+$")]
    origin: clean_str(120)
    destination: clean_str(120)
    mode: Literal["sea", "air", "road"]
    status: Literal["in_transit", "delayed", "delivered"]
    eta: datetime
    freight_cost: Money = 0


class ShipmentBatch(Strict):
    items: Annotated[list[ShipmentIn], Field(max_length=5000)]
    replace: bool = False


class GuardrailsIn(Strict):
    operator_approval_limit: Money | None = None
    hard_spend_limit: Money | None = None
    auto_approve_limit: Money | None = None
    min_runway_months: Annotated[float, Field(ge=0, le=120)] | None = None
    safety_stock_days: Annotated[int, Field(ge=0, le=365)] | None = None
    reorder_cover_days: Annotated[int, Field(ge=1, le=365)] | None = None
    max_churn_pct: Pct | None = None


class DecisionAction(Strict):
    note: Annotated[str, Field(max_length=1000)] | None = None


class DecisionAdjust(Strict):
    spend: Money
    note: Annotated[str, Field(min_length=1, max_length=1000)]


class TaskIn(Strict):
    text: clean_str(400)
    assignee: Annotated[str, Field(max_length=80)] | None = None


class TaskUpdate(Strict):
    done: bool | None = None
    assignee: Annotated[str, Field(max_length=80)] | None = None


class ChatTurn(Strict):
    role: Literal["user", "assistant"]
    content: Annotated[str, Field(min_length=1, max_length=4000)]


class ChatIn(Strict):
    message: Annotated[str, Field(min_length=1, max_length=4000)]
    history: Annotated[list[ChatTurn], Field(max_length=20)] = []
    channel: Literal["chat", "receptionist"] = "chat"


class KeyIn(Strict):
    name: Annotated[str, Field(min_length=1, max_length=80)]
    role: Literal["viewer", "operator", "owner"]
    expires_in_days: Annotated[int, Field(ge=1, le=730)] | None = 365
