"""Database tables for ELLA.

Every business-owned row carries ``business_id``. All reads and writes in the
API go through that column, which is how one business can never see another's
data.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from sqlalchemy import (
    JSON,
    Boolean,
    DateTime,
    Float,
    ForeignKey,
    Integer,
    String,
    Text,
    UniqueConstraint,
    create_engine,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker


def utcnow() -> datetime:
    return datetime.now(timezone.utc)


def new_id() -> str:
    return str(uuid.uuid4())


class Base(DeclarativeBase):
    pass


class Business(Base):
    __tablename__ = "businesses"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    name: Mapped[str] = mapped_column(String(120))
    currency: Mapped[str] = mapped_column(String(3), default="BDT")
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class ApiKey(Base):
    """API keys. Only an HMAC of the key is stored, never the key itself."""

    __tablename__ = "api_keys"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    business_id: Mapped[str] = mapped_column(ForeignKey("businesses.id"), index=True)
    name: Mapped[str] = mapped_column(String(80))
    role: Mapped[str] = mapped_column(String(16))  # viewer | operator | owner
    prefix: Mapped[str] = mapped_column(String(16))  # shown to humans to tell keys apart
    key_hash: Mapped[str] = mapped_column(String(64), unique=True, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    expires_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    last_used_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)
    revoked: Mapped[bool] = mapped_column(Boolean, default=False)


class Guardrails(Base):
    """Limits the business sets. Enforced in server code, never by the model."""

    __tablename__ = "guardrails"

    business_id: Mapped[str] = mapped_column(ForeignKey("businesses.id"), primary_key=True)
    # Spend an operator may approve on their own
    operator_approval_limit: Mapped[float] = mapped_column(Float, default=50_000)
    # Nothing above this can be approved by anyone until the owner raises it
    hard_spend_limit: Mapped[float] = mapped_column(Float, default=1_000_000)
    # Reorders at or under this amount approve themselves (0 = off)
    auto_approve_limit: Mapped[float] = mapped_column(Float, default=0)
    min_runway_months: Mapped[float] = mapped_column(Float, default=6)
    safety_stock_days: Mapped[int] = mapped_column(Integer, default=7)
    reorder_cover_days: Mapped[int] = mapped_column(Integer, default=30)
    max_churn_pct: Mapped[float] = mapped_column(Float, default=5)


class Snapshot(Base):
    """One period's numbers (normally a month, or a rolling 30 days)."""

    __tablename__ = "snapshots"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    business_id: Mapped[str] = mapped_column(ForeignKey("businesses.id"), index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    period_label: Mapped[str] = mapped_column(String(40))
    data: Mapped[dict] = mapped_column(JSON)


class Sku(Base):
    __tablename__ = "skus"
    __table_args__ = (UniqueConstraint("business_id", "code"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    business_id: Mapped[str] = mapped_column(ForeignKey("businesses.id"), index=True)
    code: Mapped[str] = mapped_column(String(64))
    name: Mapped[str] = mapped_column(String(160))
    stock_on_hand: Mapped[float] = mapped_column(Float)
    daily_sales: Mapped[float] = mapped_column(Float)
    lead_time_days: Mapped[float] = mapped_column(Float)
    unit_cost: Mapped[float] = mapped_column(Float)


class Shipment(Base):
    __tablename__ = "shipments"
    __table_args__ = (UniqueConstraint("business_id", "reference"),)

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    business_id: Mapped[str] = mapped_column(ForeignKey("businesses.id"), index=True)
    reference: Mapped[str] = mapped_column(String(64))
    origin: Mapped[str] = mapped_column(String(120))
    destination: Mapped[str] = mapped_column(String(120))
    mode: Mapped[str] = mapped_column(String(8))  # sea | air | road
    status: Mapped[str] = mapped_column(String(16))  # in_transit | delayed | delivered
    eta: Mapped[datetime] = mapped_column(DateTime(timezone=True))
    freight_cost: Mapped[float] = mapped_column(Float, default=0)


class Decision(Base):
    __tablename__ = "decisions"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    business_id: Mapped[str] = mapped_column(ForeignKey("businesses.id"), index=True)
    # Stops the same issue being raised twice while one is still open
    dedupe_key: Mapped[str] = mapped_column(String(160), index=True)
    kind: Mapped[str] = mapped_column(String(32))
    title: Mapped[str] = mapped_column(String(240))
    reasoning: Mapped[str] = mapped_column(Text)
    recommendation: Mapped[str] = mapped_column(Text)
    confidence: Mapped[float] = mapped_column(Float)
    spend: Mapped[float] = mapped_column(Float, default=0)
    impact: Mapped[str] = mapped_column(String(240), default="")
    task_text: Mapped[str | None] = mapped_column(String(400), nullable=True)
    source: Mapped[str] = mapped_column(String(16), default="rules")  # rules | ella
    status: Mapped[str] = mapped_column(String(16), default="pending")
    resolved_by: Mapped[str | None] = mapped_column(String(32), nullable=True)
    resolution_note: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    resolved_at: Mapped[datetime | None] = mapped_column(DateTime(timezone=True), nullable=True)


class Task(Base):
    __tablename__ = "tasks"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=new_id)
    business_id: Mapped[str] = mapped_column(ForeignKey("businesses.id"), index=True)
    decision_id: Mapped[str | None] = mapped_column(ForeignKey("decisions.id"), nullable=True)
    text: Mapped[str] = mapped_column(String(400))
    assignee: Mapped[str | None] = mapped_column(String(80), nullable=True)
    done: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)


class AuditEvent(Base):
    """Append-only record of who did what. Chat content is not stored."""

    __tablename__ = "audit_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    business_id: Mapped[str | None] = mapped_column(String(36), index=True, nullable=True)
    at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utcnow)
    actor: Mapped[str] = mapped_column(String(32))  # key prefix, "system", or "ella"
    action: Mapped[str] = mapped_column(String(48))
    target: Mapped[str | None] = mapped_column(String(64), nullable=True)
    ip: Mapped[str | None] = mapped_column(String(64), nullable=True)
    detail: Mapped[dict] = mapped_column(JSON, default=dict)


def make_session_factory(database_url: str):
    connect_args = {"check_same_thread": False} if database_url.startswith("sqlite") else {}
    engine = create_engine(database_url, connect_args=connect_args, pool_pre_ping=True)
    Base.metadata.create_all(engine)
    return sessionmaker(engine, expire_on_commit=False)
