from __future__ import annotations

from datetime import timedelta
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from ella.api import create_app
from ella.config import Settings
from ella.models import Business, Shipment, Sku, Snapshot, utcnow
from ella.security import create_api_key

PEPPER = "test-pepper-" + "x" * 40

SNAPSHOT = {
    "period_label": "September",
    "revenue": 1_260_000, "cogs": 640_000, "returns": 38_000, "operating_expenses": 420_000,
    "orders": 685, "cash_on_hand": 1_080_000, "monthly_burn": 150_000,
    "on_time_deliveries": 482, "total_deliveries": 500, "marketing_spend": 58_000,
    "new_customers": 138, "customers_lost": 40, "total_customers": 950,
    "accounts_receivable": 340_000, "fixed_costs": 260_000, "employees": 21, "utilization_pct": 88,
}


class FakeLLM:
    """Stands in for the Anthropic client. Plays back scripted turns."""

    def __init__(self, turns):
        self.turns = list(turns)
        self.calls = []
        self.messages = SimpleNamespace(create=self._create)

    def _create(self, **kwargs):
        self.calls.append(kwargs)
        turn = self.turns.pop(0)
        if isinstance(turn, str):
            return SimpleNamespace(stop_reason="end_turn", content=[SimpleNamespace(type="text", text=turn)])
        blocks = [SimpleNamespace(type="tool_use", id=f"tu_{i}", name=name, input=args)
                  for i, (name, args) in enumerate(turn)]
        return SimpleNamespace(stop_reason="tool_use", content=blocks)


def make_settings(tmp_path, **over) -> Settings:
    base = dict(database_url=f"sqlite:///{tmp_path}/t.db", key_pepper=PEPPER,
                auth_failures_per_minute=20, rate_limit_per_minute=1000, chat_rate_limit_per_minute=1000)
    base.update(over)
    return Settings(**base)


class World:
    def __init__(self, app):
        self.app = app
        self.client = TestClient(app)
        self.Session = app.state.session_factory
        self.keys: dict[str, str] = {}
        self.business: dict[str, str] = {}

    def add_business(self, label: str, name: str):
        with self.Session() as db:
            b = Business(name=name, currency="BDT")
            db.add(b)
            db.flush()
            for role in ("viewer", "operator", "owner"):
                _, plain = create_api_key(db, business_id=b.id, name=role, role=role, pepper=PEPPER)
                self.keys[f"{label}:{role}"] = plain
            self.business[label] = b.id
            db.commit()

    def h(self, who: str) -> dict[str, str]:
        return {"Authorization": f"Bearer {self.keys[who]}"}

    def load_demo(self, label: str = "a"):
        bid = self.business[label]
        with self.Session() as db:
            db.add(Snapshot(business_id=bid, period_label="August",
                            data={**{k: v for k, v in SNAPSHOT.items() if k != "period_label"},
                                  "period_days": 30, "cogs": 560_000}))
            db.commit()
        r = self.client.put("/v1/data/skus", headers=self.h(f"{label}:operator"), json={"items": [
            {"code": "SAR-001", "name": "Cotton saree", "stock_on_hand": 120, "daily_sales": 9,
             "lead_time_days": 14, "unit_cost": 850},
            {"code": "LUN-203", "name": "Check lungi", "stock_on_hand": 900, "daily_sales": 18,
             "lead_time_days": 10, "unit_cost": 260},
        ]})
        assert r.status_code == 200, r.text
        with self.Session() as db:
            db.add(Shipment(business_id=bid, reference="SHP-1", origin="Chattogram", destination="Sylhet",
                            mode="road", status="in_transit", eta=utcnow() - timedelta(days=1), freight_cost=12_000))
            db.commit()
        r = self.client.put("/v1/data/snapshot", headers=self.h(f"{label}:operator"), json=SNAPSHOT)
        assert r.status_code == 201, r.text
        return r.json()


@pytest.fixture
def world(tmp_path):
    app = create_app(make_settings(tmp_path))
    w = World(app)
    w.add_business("a", "Anka Retail")
    w.add_business("b", "Meghna Textiles")
    return w


@pytest.fixture
def make_world(tmp_path):
    def _make(llm=None, **settings_over):
        app = create_app(make_settings(tmp_path, **settings_over), llm_client=llm)
        w = World(app)
        w.add_business("a", "Anka Retail")
        w.add_business("b", "Meghna Textiles")
        return w
    return _make
