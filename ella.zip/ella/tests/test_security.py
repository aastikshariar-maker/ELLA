from datetime import timedelta

import pytest
from sqlalchemy import select

from ella.api import create_app
from ella.config import load_settings
from ella.models import ApiKey, AuditEvent, utcnow

from .conftest import make_settings


def test_every_route_needs_a_key(world):
    paths = [("get", "/v1/metrics"), ("get", "/v1/decisions"), ("get", "/v1/tasks"),
             ("post", "/v1/ella/chat"), ("get", "/v1/keys"), ("get", "/v1/audit")]
    for method, path in paths:
        r = getattr(world.client, method)(path)
        assert r.status_code == 401, path
        assert r.json() == {"error": "unauthorized"}


def test_wrong_and_malformed_keys_rejected(world):
    for header in ("Bearer ella_nope", "Basic abc", "ella_" + "x" * 43, "Bearer " + "ella_" + "a" * 200, ""):
        assert world.client.get("/v1/metrics", headers={"Authorization": header}).status_code == 401


def test_keys_are_stored_hashed_only(world):
    with world.Session() as db:
        rows = db.scalars(select(ApiKey)).all()
        stored = " ".join(f"{r.key_hash} {r.prefix} {r.name}" for r in rows)
    for plain in world.keys.values():
        assert plain not in stored
        assert plain[12:] not in stored  # nothing beyond the short prefix


def test_revoked_and_expired_keys_stop_working(world):
    a = world.business["a"]
    assert world.client.get("/v1/metrics", headers=world.h("a:viewer")).status_code == 200
    with world.Session() as db:
        db.scalars(select(ApiKey).where(ApiKey.business_id == a, ApiKey.role == "viewer")).one().revoked = True
        db.scalars(select(ApiKey).where(ApiKey.business_id == a, ApiKey.role == "operator")).one().expires_at = (
            utcnow() - timedelta(seconds=1))
        db.commit()
    assert world.client.get("/v1/metrics", headers=world.h("a:viewer")).status_code == 401
    assert world.client.get("/v1/metrics", headers=world.h("a:operator")).status_code == 401
    assert world.client.get("/v1/metrics", headers=world.h("a:owner")).status_code == 200


def test_roles_are_enforced(world):
    snap = {"period_label": "x", "revenue": 1}
    assert world.client.put("/v1/data/snapshot", headers=world.h("a:viewer"), json=snap).status_code == 403
    assert world.client.put("/v1/data/snapshot", headers=world.h("a:operator"), json=snap).status_code == 201
    assert world.client.put("/v1/guardrails", headers=world.h("a:operator"), json={"hard_spend_limit": 1}).status_code == 403
    assert world.client.get("/v1/keys", headers=world.h("a:operator")).status_code == 403
    assert world.client.get("/v1/audit", headers=world.h("a:operator")).status_code == 403
    r = world.client.post("/v1/keys", headers=world.h("a:operator"), json={"name": "x", "role": "owner"})
    assert r.status_code == 403  # no privilege escalation


def test_businesses_cannot_see_each_other(world):
    world.load_demo("a")
    a_decisions = world.client.get("/v1/decisions", headers=world.h("a:viewer")).json()
    assert a_decisions
    did = a_decisions[0]["id"]

    assert world.client.get("/v1/decisions", headers=world.h("b:viewer")).json() == []
    assert world.client.get("/v1/metrics", headers=world.h("b:viewer")).json()["kpis"] is None
    assert world.client.get("/v1/inventory", headers=world.h("b:viewer")).json()["skus_tracked"] == 0
    # B's owner gets "not found", exactly like a made-up id
    r = world.client.post(f"/v1/decisions/{did}/approve", headers=world.h("b:owner"), json={})
    assert r.status_code == 404
    fake = world.client.post("/v1/decisions/00000000-0000-0000-0000-000000000000/approve",
                             headers=world.h("b:owner"), json={})
    assert fake.status_code == 404 and fake.json()["error"] == r.json()["error"]
    # nor revoke A's keys
    a_keys = world.client.get("/v1/keys", headers=world.h("a:owner")).json()
    assert world.client.delete(f"/v1/keys/{a_keys[0]['id']}", headers=world.h("b:owner")).status_code == 404


def test_validation_rejects_bad_and_unknown_fields(world):
    h = world.h("a:operator")
    assert world.client.put("/v1/data/snapshot", headers=h, json={"period_label": "x", "revenue": -5}).status_code == 422
    assert world.client.put("/v1/data/snapshot", headers=h, json={"period_label": "x", "revenue": 1, "is_admin": True}).status_code == 422
    bad_code = {"items": [{"code": "<script>", "name": "x", "stock_on_hand": 1, "daily_sales": 1, "lead_time_days": 1, "unit_cost": 1}]}
    assert world.client.put("/v1/data/skus", headers=h, json=bad_code).status_code == 422
    r = world.client.post("/v1/ella/chat", headers=h, json={"message": "x" * 4001})
    assert r.status_code == 422
    assert "Traceback" not in r.text


def test_body_size_limit(make_world):
    w = make_world(max_body_bytes=2000)
    r = w.client.post("/v1/ella/chat", headers=w.h("a:viewer"), json={"message": "hi", "history": [{"role": "user", "content": "y" * 3000}]})
    assert r.status_code == 413


def test_security_headers(world):
    r = world.client.get("/health")
    assert r.headers["x-content-type-options"] == "nosniff"
    assert r.headers["x-frame-options"] == "DENY"
    assert "default-src 'none'" in r.headers["content-security-policy"]
    assert r.headers["cache-control"] == "no-store"


def test_hsts_and_no_docs_in_production(tmp_path):
    app = create_app(make_settings(tmp_path, environment="production"))
    from fastapi.testclient import TestClient
    c = TestClient(app)
    assert "max-age" in c.get("/health").headers["strict-transport-security"]
    assert c.get("/docs").status_code == 404
    assert c.get("/openapi.json").status_code == 404


def test_production_refuses_to_start_without_pepper(monkeypatch):
    monkeypatch.setenv("ELLA_ENV", "production")
    monkeypatch.delenv("ELLA_KEY_PEPPER", raising=False)
    with pytest.raises(RuntimeError):
        load_settings()
    monkeypatch.setenv("ELLA_KEY_PEPPER", "short")
    with pytest.raises(RuntimeError):
        load_settings()


def test_brute_force_is_throttled(make_world):
    w = make_world(auth_failures_per_minute=5)
    for _ in range(5):
        assert w.client.get("/v1/metrics", headers={"Authorization": "Bearer ella_guess"}).status_code == 401
    # now even the right key is blocked from this address for a minute
    r = w.client.get("/v1/metrics", headers=w.h("a:viewer"))
    assert r.status_code == 429
    assert r.headers["retry-after"]


def test_per_key_rate_limit(make_world):
    w = make_world(rate_limit_per_minute=3)
    codes = [w.client.get("/v1/metrics", headers=w.h("a:viewer")).status_code for _ in range(4)]
    assert codes == [200, 200, 200, 429]
    # a different key is unaffected
    assert w.client.get("/v1/metrics", headers=w.h("b:viewer")).status_code == 200


def test_new_key_shown_once_and_audited(world):
    r = world.client.post("/v1/keys", headers=world.h("a:owner"), json={"name": "laptop", "role": "viewer"})
    assert r.status_code == 201
    plain = r.json()["key"]
    assert world.client.get("/v1/metrics", headers={"Authorization": f"Bearer {plain}"}).status_code == 200
    listed = world.client.get("/v1/keys", headers=world.h("a:owner")).json()
    assert plain not in str(listed)
    actions = [e["action"] for e in world.client.get("/v1/audit", headers=world.h("a:owner")).json()]
    assert "key.create" in actions


def test_owner_cannot_lock_themselves_out(world):
    keys = world.client.get("/v1/keys", headers=world.h("a:owner")).json()
    mine = next(k for k in keys if k["role"] == "owner")
    assert world.client.delete(f"/v1/keys/{mine['id']}", headers=world.h("a:owner")).status_code == 409


def test_failed_logins_are_audited_without_the_key(world):
    world.client.get("/v1/metrics", headers={"Authorization": "Bearer ella_secretguess123"})
    with world.Session() as db:
        events = db.scalars(select(AuditEvent).where(AuditEvent.action == "auth.failed")).all()
    assert events
    assert "secretguess" not in str([e.detail for e in events])
