from datetime import datetime, timedelta, timezone

from ella import calc


def test_kpis_match_hand_calculation():
    k = calc.compute_kpis({
        "revenue": 1000, "cogs": 400, "returns": 100, "operating_expenses": 300, "orders": 10,
        "cash_on_hand": 1200, "monthly_burn": 200, "total_customers": 50, "customers_lost": 5,
        "marketing_spend": 100, "new_customers": 4, "fixed_costs": 250,
    })
    assert k["net_revenue"] == 900
    assert k["net_profit"] == 200            # 1000 - 100 - 400 - 300
    assert k["gross_margin_pct"] == 55.56    # (900 - 400) / 900
    assert k["contribution_margin_pct"] == 50.0  # (1000 - 400 - 100) / 1000
    assert k["cash_runway_months"] == 6.0
    assert k["average_order_value"] == 100
    assert k["churn_rate_pct"] == 10.0
    assert k["customer_acquisition_cost"] == 25
    assert k["break_even_orders"] == 5       # 250 / (100 * 0.5)


def test_no_divide_by_zero_and_none_when_unknown():
    k = calc.compute_kpis({"revenue": 0})
    assert k["gross_margin_pct"] is None
    assert k["average_order_value"] is None
    assert k["cash_runway_months"] is None
    assert k["churn_rate_pct"] is None
    assert k["customer_lifetime_value"] is None


def test_burn_derived_from_loss_when_not_given():
    k = calc.compute_kpis({"revenue": 100, "cogs": 50, "operating_expenses": 150, "cash_on_hand": 1000, "period_days": 15})
    # loss of 100 over 15 days = 200 per 30-day month
    assert k["monthly_burn"] == 200
    assert k["cash_runway_months"] == 5.0


def test_profitable_business_has_no_runway_limit():
    k = calc.compute_kpis({"revenue": 1000, "cogs": 100, "cash_on_hand": 50})
    assert k["monthly_burn"] == 0
    assert k["cash_runway_months"] is None


def test_sku_status_and_reorder():
    sku = calc.SkuView("A", "a", stock_on_hand=50, daily_sales=10, lead_time_days=7, unit_cost=2)
    assert calc.sku_status(sku, safety_days=7)["status"] == "critical"   # 5 days < 7 lead
    sku.stock_on_hand = 100                                              # 10 days
    assert calc.sku_status(sku, safety_days=7)["status"] == "low"        # < 7 + 7
    sku.stock_on_hand = 200
    assert calc.sku_status(sku, safety_days=7)["status"] == "healthy"
    sku.stock_on_hand = 50
    assert calc.reorder_quantity(sku, 7, 30) == 10 * (7 + 7 + 30) - 50
    idle = calc.SkuView("B", "b", 5, 0, 7, 1)
    assert calc.sku_status(idle, 7)["status"] == "healthy"


def test_shipment_past_eta_counts_as_delayed():
    now = datetime(2026, 1, 10, tzinfo=timezone.utc)
    late = calc.ShipmentView("S1", "x", "y", "road", "in_transit", now - timedelta(hours=1), 0)
    fine = calc.ShipmentView("S2", "x", "y", "road", "in_transit", now + timedelta(days=1), 0)
    done = calc.ShipmentView("S3", "x", "y", "road", "delivered", now - timedelta(days=3), 0)
    assert calc.shipment_status(late, now) == "delayed"
    assert calc.shipment_status(fine, now) == "in_transit"
    assert calc.shipment_status(done, now) == "delivered"
