def _pending(world, label="a"):
    return world.client.get("/v1/decisions", headers=world.h(f"{label}:viewer")).json()


def test_live_model_raises_the_right_decisions(world):
    out = world.load_demo("a")
    kinds = {d["kind"] for d in _pending(world)}
    assert {"reorder", "margin", "fulfillment"} <= kinds
    reorder = next(d for d in _pending(world) if d["kind"] == "reorder")
    assert "SAR-001" in reorder["title"]
    assert reorder["spend"] == (9 * (14 + 7 + 30) - 120) * 850
    assert "lead time" in reorder["reasoning"]
    assert out["metrics"]["kpis"]["cash_runway_months"] == 7.2


def test_no_duplicates_while_a_decision_is_open(world):
    world.load_demo("a")
    before = len(_pending(world))
    world.client.post("/v1/decisions/refresh", headers=world.h("a:operator"))
    world.client.post("/v1/decisions/refresh", headers=world.h("a:operator"))
    assert len(_pending(world)) == before


def test_spending_limits(world):
    world.load_demo("a")
    reorder = next(d for d in _pending(world) if d["kind"] == "reorder")  # 288,150 BDT
    url = f"/v1/decisions/{reorder['id']}"

    assert world.client.post(url + "/approve", headers=world.h("a:viewer"), json={}).status_code == 403
    r = world.client.post(url + "/approve", headers=world.h("a:operator"), json={})
    assert r.status_code == 403 and r.json()["error"] == "needs_owner"

    # operator can approve a smaller version that fits their limit
    r = world.client.post(url + "/adjust", headers=world.h("a:operator"), json={"spend": 40_000, "note": "half order"})
    assert r.status_code == 200 and r.json()["status"] == "adjusted"
    # and it can't be resolved twice
    assert world.client.post(url + "/approve", headers=world.h("a:owner"), json={}).status_code == 409

    tasks = world.client.get("/v1/tasks", headers=world.h("a:viewer")).json()
    assert any("SAR-001" in t["text"] and "half order" in t["text"] for t in tasks)


def test_hard_limit_blocks_even_owners(world):
    world.load_demo("a")
    world.client.put("/v1/guardrails", headers=world.h("a:owner"), json={"hard_spend_limit": 100_000, "operator_approval_limit": 50_000})
    reorder = next(d for d in _pending(world) if d["kind"] == "reorder")
    r = world.client.post(f"/v1/decisions/{reorder['id']}/approve", headers=world.h("a:owner"), json={})
    assert r.status_code == 409 and r.json()["error"] == "over_hard_limit"
    # refused attempts are on the record
    actions = [e["action"] for e in world.client.get("/v1/audit", headers=world.h("a:owner")).json()]
    assert "decision.approve.refused" in actions


def test_inconsistent_guardrails_rejected(world):
    r = world.client.put("/v1/guardrails", headers=world.h("a:owner"), json={"operator_approval_limit": 10, "hard_spend_limit": 5})
    assert r.status_code == 422
    # the rejected change did not stick
    assert world.client.get("/v1/guardrails", headers=world.h("a:owner")).json()["hard_spend_limit"] == 1_000_000


def test_auto_approve_small_reorders(world):
    world.client.put("/v1/guardrails", headers=world.h("a:owner"), json={"auto_approve_limit": 500_000})
    world.load_demo("a")
    approved = world.client.get("/v1/decisions?status=approved", headers=world.h("a:viewer")).json()
    assert any(d["kind"] == "reorder" and d["resolved_by"] == "auto" for d in approved)
    # only reorders auto-approve; the margin alert still waits for a person
    assert any(d["kind"] == "margin" for d in _pending(world))


def test_owner_approval_creates_task(world):
    world.load_demo("a")
    reorder = next(d for d in _pending(world) if d["kind"] == "reorder")
    r = world.client.post(f"/v1/decisions/{reorder['id']}/approve", headers=world.h("a:owner"), json={"note": "go"})
    assert r.status_code == 200
    tasks = world.client.get("/v1/tasks", headers=world.h("a:viewer")).json()
    task = next(t for t in tasks if t["decision_id"] == reorder["id"])
    assert "purchase order" in task["text"].lower()
    r = world.client.patch(f"/v1/tasks/{task['id']}", headers=world.h("a:operator"), json={"done": True})
    assert r.json()["done"] is True
