"""Admin commands (run on the server, not over the internet).

    python -m ella create-business "Anka Retail" --currency BDT
    python -m ella create-key <business_id> "Ops laptop" operator
    python -m ella revoke-key <key_id>
    python -m ella load-demo <business_id>
"""

from __future__ import annotations

import argparse
import sys
from datetime import timedelta

from . import audit, decisions
from .config import load_settings
from .models import ApiKey, Business, Shipment, Sku, Snapshot, make_session_factory, utcnow
from .security import create_api_key


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m ella")
    sub = parser.add_subparsers(dest="cmd", required=True)

    cb = sub.add_parser("create-business", help="Create a business and its first owner key")
    cb.add_argument("name")
    cb.add_argument("--currency", default="BDT")

    ck = sub.add_parser("create-key", help="Create an API key")
    ck.add_argument("business_id")
    ck.add_argument("name")
    ck.add_argument("role", choices=["viewer", "operator", "owner"])
    ck.add_argument("--days", type=int, default=365)

    rk = sub.add_parser("revoke-key", help="Revoke an API key")
    rk.add_argument("key_id")

    ld = sub.add_parser("load-demo", help="Load sample data so you can try ELLA")
    ld.add_argument("business_id")

    args = parser.parse_args(argv)
    settings = load_settings()
    Session = make_session_factory(settings.database_url)

    with Session() as db:
        if args.cmd == "create-business":
            currency = args.currency.upper()
            if len(currency) != 3 or not currency.isalpha():
                print("Currency must be a 3-letter code like BDT or USD", file=sys.stderr)
                return 2
            b = Business(name=args.name[:120], currency=currency)
            db.add(b)
            db.flush()
            row, plain = create_api_key(db, business_id=b.id, name="first owner key", role="owner",
                                        pepper=settings.key_pepper, expires_in_days=365)
            audit.record(db, business_id=b.id, actor="cli", action="business.create", target=b.id)
            db.commit()
            print(f"Business id: {b.id}")
            print(f"Owner key:   {plain}")
            print("Store the key somewhere safe now — it can't be shown again.")

        elif args.cmd == "create-key":
            if db.get(Business, args.business_id) is None:
                print("No such business", file=sys.stderr)
                return 1
            row, plain = create_api_key(db, business_id=args.business_id, name=args.name[:80], role=args.role,
                                        pepper=settings.key_pepper, expires_in_days=args.days)
            audit.record(db, business_id=args.business_id, actor="cli", action="key.create", target=row.id,
                         detail={"role": args.role})
            db.commit()
            print(f"Key id: {row.id}\nKey:    {plain}\nStore it now — it can't be shown again.")

        elif args.cmd == "revoke-key":
            row = db.get(ApiKey, args.key_id)
            if row is None:
                print("No such key", file=sys.stderr)
                return 1
            row.revoked = True
            audit.record(db, business_id=row.business_id, actor="cli", action="key.revoke", target=row.id)
            db.commit()
            print("Revoked.")

        elif args.cmd == "load-demo":
            bid = args.business_id
            if db.get(Business, bid) is None:
                print("No such business", file=sys.stderr)
                return 1
            base = dict(period_days=30, cogs=640_000, returns=38_000, operating_expenses=420_000, orders=685,
                        cash_on_hand=1_080_000, monthly_burn=150_000, on_time_deliveries=482, total_deliveries=500,
                        marketing_spend=58_000, new_customers=138, customers_lost=40, total_customers=950,
                        accounts_receivable=340_000, fixed_costs=260_000, employees=21, utilization_pct=88)
            db.add(Snapshot(business_id=bid, period_label="August", data={**base, "revenue": 1_190_000, "cogs": 590_000}))
            db.flush()
            db.add(Snapshot(business_id=bid, period_label="September", data={**base, "revenue": 1_260_000}))
            for code, name, stock, daily, lead, cost in [
                ("SAR-001", "Cotton saree, blue", 120, 9, 14, 850),
                ("SAR-014", "Jamdani saree", 40, 4, 21, 3200),
                ("LUN-203", "Check lungi", 900, 18, 10, 260),
                ("GAM-077", "Gamcha, red check", 60, 12, 7, 90),
                ("PNJ-310", "Men's panjabi", 310, 6, 18, 1100),
            ]:
                db.add(Sku(business_id=bid, code=code, name=name, stock_on_hand=stock, daily_sales=daily,
                           lead_time_days=lead, unit_cost=cost))
            now = utcnow()
            for ref, dest, mode, status, eta_days, freight in [
                ("SHP-1041", "Dhaka", "road", "in_transit", 2, 18_000),
                ("SHP-1042", "Sylhet", "road", "in_transit", -1, 12_500),
                ("SHP-1043", "Singapore", "sea", "in_transit", 9, 96_000),
                ("SHP-1044", "Dubai", "air", "delivered", -3, 54_000),
            ]:
                db.add(Shipment(business_id=bid, reference=ref, origin="Chattogram warehouse", destination=dest,
                                mode=mode, status=status, eta=now + timedelta(days=eta_days), freight_cost=freight))
            db.flush()
            created = decisions.refresh(db, bid, actor="cli", ip=None)
            db.commit()
            print(f"Demo data loaded. {len(created)} decision(s) raised:")
            for d in created:
                print(f"  - {d.title}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
