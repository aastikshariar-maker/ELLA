"""Entry point: ``uvicorn ella.main:app --host 127.0.0.1 --port 8100``."""

from .api import create_app

app = create_app()
