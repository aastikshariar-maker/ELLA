"""The live model: every number ELLA talks about is computed here.

These are plain functions with no AI in them, so the numbers are exact,
repeatable and testable. ELLA reads their output; she never does the
arithmetic herself.

Any metric that cannot be computed (for example margin with zero revenue)
comes back as ``None`` instead of a misleading 0 or a crash.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Iterable


def _div(numerator: float, denominator: float) -> float | None:
    if not denominator:
        return None
    return numerator / denominator


def _round(value: float | None, places: int = 2) -> float | None:
    return None if value is None else round(value, places)


def _pct(value: float | None) -> float | None:
    return None if value is None else round(value * 100, 2)


def compute_kpis(s: dict[str, Any]) -> dict[str, float | None]:
    """KPIs for one period snapshot."""
    revenue = s.get("revenue", 0) or 0
    cogs = s.get("cogs", 0) or 0
    returns = s.get("returns", 0) or 0
    opex = s.get("operating_expenses", 0) or 0
    orders = s.get("orders", 0) or 0
    period_days = s.get("period_days", 30) or 30

    net_revenue = revenue - returns
    gross_profit = net_revenue - cogs
    net_profit = gross_profit - opex

    # Burn: use the figure given, otherwise derive it from the loss (if any),
    # scaled to a 30-day month.
    burn = s.get("monthly_burn")
    if burn is None:
        loss = -net_profit if net_profit < 0 else 0.0
        burn = loss * 30 / period_days
    runway = _div(s.get("cash_on_hand", 0) or 0, burn) if burn else None

    aov = _div(revenue, orders)
    contribution_margin = _div(revenue - cogs - returns, revenue)
    total_customers = s.get("total_customers", 0) or 0
    churn = _div(s.get("customers_lost", 0) or 0, total_customers)
    orders_per_customer = _div(orders, total_customers)

    # Lifetime value = margin a customer brings per period / chance they leave
    ltv = None
    if aov is not None and contribution_margin is not None and orders_per_customer and churn:
        ltv = aov * orders_per_customer * contribution_margin / churn

    contribution_per_order = (
        aov * contribution_margin if aov is not None and contribution_margin is not None else None
    )
    break_even_units = (
        _div(s.get("fixed_costs", 0) or 0, contribution_per_order)
        if contribution_per_order and contribution_per_order > 0
        else None
    )

    return {
        "gross_sales": _round(revenue),
        "net_revenue": _round(net_revenue),
        "net_profit": _round(net_profit),
        "average_order_value": _round(aov),
        "gross_margin_pct": _pct(_div(gross_profit, net_revenue)),
        "contribution_margin_pct": _pct(contribution_margin),
        "operating_margin_pct": _pct(_div(net_profit, net_revenue)),
        "monthly_burn": _round(burn),
        "cash_on_hand": _round(s.get("cash_on_hand", 0) or 0),
        "cash_runway_months": _round(runway, 1),
        "on_time_fulfillment_pct": _pct(
            _div(s.get("on_time_deliveries", 0) or 0, s.get("total_deliveries", 0) or 0)
        ),
        "customer_acquisition_cost": _round(
            _div(s.get("marketing_spend", 0) or 0, s.get("new_customers", 0) or 0)
        ),
        "customer_lifetime_value": _round(ltv),
        "churn_rate_pct": _pct(churn),
        "revenue_per_employee": _round(_div(revenue, s.get("employees", 0) or 0)),
        "headcount_utilization_pct": _round(s.get("utilization_pct")),
        "accounts_receivable": _round(s.get("accounts_receivable", 0) or 0),
        "receivables_to_revenue_pct": _pct(_div(s.get("accounts_receivable", 0) or 0, revenue)),
        "break_even_orders": _round(break_even_units, 0),
    }


def compare(current: dict[str, float | None], previous: dict[str, float | None] | None) -> dict[str, float | None]:
    """Change in each KPI against the previous period (``None`` if unknown)."""
    if not previous:
        return {key: None for key in current}
    out: dict[str, float | None] = {}
    for key, value in current.items():
        before = previous.get(key)
        out[key] = None if value is None or before is None else round(value - before, 2)
    return out


@dataclass
class SkuView:
    code: str
    name: str
    stock_on_hand: float
    daily_sales: float
    lead_time_days: float
    unit_cost: float


def sku_status(sku: SkuView, safety_days: int) -> dict[str, Any]:
    """Will this SKU run out before a new order could arrive?"""
    days_of_supply = _div(sku.stock_on_hand, sku.daily_sales)
    if days_of_supply is None:  # nothing selling
        status = "healthy"
    elif days_of_supply < sku.lead_time_days:
        status = "critical"  # runs out before a reorder placed today lands
    elif days_of_supply < sku.lead_time_days + safety_days:
        status = "low"
    else:
        status = "healthy"
    return {
        "code": sku.code,
        "name": sku.name,
        "stock_on_hand": sku.stock_on_hand,
        "daily_sales": sku.daily_sales,
        "days_of_supply": _round(days_of_supply, 1),
        "lead_time_days": sku.lead_time_days,
        "value": _round(sku.stock_on_hand * sku.unit_cost),
        "status": status,
    }


def reorder_quantity(sku: SkuView, safety_days: int, cover_days: int) -> float:
    """Units needed to cover lead time + safety stock + the cover period."""
    target = sku.daily_sales * (sku.lead_time_days + safety_days + cover_days)
    return max(0.0, round(target - sku.stock_on_hand))


def inventory_summary(skus: Iterable[SkuView], safety_days: int) -> dict[str, Any]:
    rows = [sku_status(s, safety_days) for s in skus]
    lead_times = [r["lead_time_days"] for r in rows]
    return {
        "skus_tracked": len(rows),
        "total_inventory_value": round(sum(r["value"] or 0 for r in rows), 2),
        "critical": sum(r["status"] == "critical" for r in rows),
        "low": sum(r["status"] == "low" for r in rows),
        "average_lead_time_days": _round(sum(lead_times) / len(lead_times), 1) if lead_times else None,
        "items": sorted(rows, key=lambda r: (r["days_of_supply"] is None, r["days_of_supply"] or 0)),
    }


@dataclass
class ShipmentView:
    reference: str
    origin: str
    destination: str
    mode: str
    status: str
    eta: datetime
    freight_cost: float


def shipment_status(sh: ShipmentView, now: datetime | None = None) -> str:
    now = now or datetime.now(timezone.utc)
    eta = sh.eta if sh.eta.tzinfo else sh.eta.replace(tzinfo=timezone.utc)
    if sh.status == "delivered":
        return "delivered"
    if sh.status == "delayed" or eta < now:
        return "delayed"  # past its promised ETA and still not delivered
    return "in_transit"


def shipments_summary(shipments: Iterable[ShipmentView], now: datetime | None = None) -> dict[str, Any]:
    rows = []
    for sh in shipments:
        status = shipment_status(sh, now)
        rows.append(
            {
                "reference": sh.reference,
                "origin": sh.origin,
                "destination": sh.destination,
                "mode": sh.mode,
                "status": status,
                "eta": sh.eta.isoformat(),
                "freight_cost": sh.freight_cost,
            }
        )
    active = [r for r in rows if r["status"] != "delivered"]
    return {
        "active": len(active),
        "delayed": sum(r["status"] == "delayed" for r in rows),
        "on_time": sum(r["status"] == "in_transit" for r in rows),
        "freight_in_transit": round(sum(r["freight_cost"] for r in active), 2),
        "items": rows,
    }
