"""Loads one business's data and runs the live model over it.

Every function here takes ``business_id`` and filters by it. Nothing in this
module can reach another business's rows.
"""

from __future__ import annotations

from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import calc
from .models import Business, Guardrails, Shipment, Sku, Snapshot


def get_guardrails(db: Session, business_id: str) -> Guardrails:
    g = db.get(Guardrails, business_id)
    if g is None:
        g = Guardrails(business_id=business_id)
        db.add(g)
        db.flush()
    return g


def guardrails_dict(g: Guardrails) -> dict[str, Any]:
    return {
        "operator_approval_limit": g.operator_approval_limit,
        "hard_spend_limit": g.hard_spend_limit,
        "auto_approve_limit": g.auto_approve_limit,
        "min_runway_months": g.min_runway_months,
        "safety_stock_days": g.safety_stock_days,
        "reorder_cover_days": g.reorder_cover_days,
        "max_churn_pct": g.max_churn_pct,
    }


def latest_snapshots(db: Session, business_id: str, n: int = 2) -> list[Snapshot]:
    stmt = (
        select(Snapshot)
        .where(Snapshot.business_id == business_id)
        .order_by(Snapshot.created_at.desc(), Snapshot.id.desc())
        .limit(n)
    )
    return list(db.scalars(stmt))


def sku_views(db: Session, business_id: str) -> list[calc.SkuView]:
    rows = db.scalars(select(Sku).where(Sku.business_id == business_id))
    return [
        calc.SkuView(r.code, r.name, r.stock_on_hand, r.daily_sales, r.lead_time_days, r.unit_cost)
        for r in rows
    ]


def shipment_views(db: Session, business_id: str) -> list[calc.ShipmentView]:
    rows = db.scalars(select(Shipment).where(Shipment.business_id == business_id))
    return [
        calc.ShipmentView(r.reference, r.origin, r.destination, r.mode, r.status, r.eta, r.freight_cost)
        for r in rows
    ]


def metrics(db: Session, business_id: str) -> dict[str, Any]:
    snaps = latest_snapshots(db, business_id)
    business = db.get(Business, business_id)
    if not snaps:
        return {
            "business": business.name if business else None,
            "currency": business.currency if business else None,
            "period": None,
            "kpis": None,
            "change_vs_previous": None,
            "note": "No numbers uploaded yet. Send a snapshot to PUT /v1/data/snapshot.",
        }
    current = calc.compute_kpis(snaps[0].data)
    previous = calc.compute_kpis(snaps[1].data) if len(snaps) > 1 else None
    return {
        "business": business.name if business else None,
        "currency": business.currency if business else None,
        "period": snaps[0].period_label,
        "previous_period": snaps[1].period_label if len(snaps) > 1 else None,
        "calculated_from": snaps[0].created_at.isoformat(),
        "kpis": current,
        "change_vs_previous": calc.compare(current, previous),
    }


def inventory(db: Session, business_id: str) -> dict[str, Any]:
    g = get_guardrails(db, business_id)
    return calc.inventory_summary(sku_views(db, business_id), g.safety_stock_days)


def shipments(db: Session, business_id: str) -> dict[str, Any]:
    return calc.shipments_summary(shipment_views(db, business_id))
