"""The decisions queue.

The live model raises decisions (with the reasoning attached). People approve,
adjust or dismiss them. The spending rules are enforced here, in code:

* viewers can't resolve decisions at all;
* operators can approve up to ``operator_approval_limit``;
* owners can approve up to ``hard_spend_limit``;
* nothing above ``hard_spend_limit`` can be approved by anyone until an owner
  raises the limit (which is itself audited);
* ELLA can only *propose* decisions. She has no code path that approves one.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from . import audit, calc, service
from .models import Decision, Task, utcnow

ROLE_RANK = {"viewer": 0, "operator": 1, "owner": 2}


class DecisionError(Exception):
    def __init__(self, status: int, code: str, message: str):
        super().__init__(message)
        self.status = status
        self.code = code
        self.message = message


@dataclass
class Draft:
    dedupe_key: str
    kind: str
    title: str
    reasoning: str
    recommendation: str
    confidence: float
    spend: float = 0.0
    impact: str = ""
    task: str | None = None


def _money(value: float, currency: str | None) -> str:
    return f"{currency or ''} {value:,.0f}".strip()


def draft_decisions(db: Session, business_id: str) -> list[Draft]:
    """Look at the live model and list what needs a human decision."""
    g = service.get_guardrails(db, business_id)
    m = service.metrics(db, business_id)
    currency = m.get("currency")
    drafts: list[Draft] = []

    # 1. Stock that will run out
    for sku in service.sku_views(db, business_id):
        row = calc.sku_status(sku, g.safety_stock_days)
        if row["status"] not in ("critical", "low"):
            continue
        qty = calc.reorder_quantity(sku, g.safety_stock_days, g.reorder_cover_days)
        if qty <= 0:
            continue
        cost = round(qty * sku.unit_cost, 2)
        critical = row["status"] == "critical"
        drafts.append(
            Draft(
                dedupe_key=f"reorder:{sku.code}",
                kind="reorder",
                title=f"Reorder {qty:,.0f} units of {sku.code}",
                reasoning=(
                    f"{row['days_of_supply']} days of stock left at {sku.daily_sales:g}/day; "
                    f"supplier lead time is {sku.lead_time_days:g} days"
                    + (" — it will run out before a new order arrives." if critical
                       else f", inside the {g.safety_stock_days}-day safety buffer.")
                ),
                recommendation=(
                    f"Order {qty:,.0f} units to cover lead time + {g.safety_stock_days} safety days "
                    f"+ {g.reorder_cover_days} days of sales."
                ),
                confidence=0.92 if critical else 0.8,
                spend=cost,
                impact=f"Costs {_money(cost, currency)}; avoids a stockout",
                task=f"Place purchase order: {qty:,.0f} × {sku.code} ({sku.name})",
            )
        )

    kpis = m.get("kpis") or {}
    delta = m.get("change_vs_previous") or {}

    # 2. Cash runway below the floor
    runway = kpis.get("cash_runway_months")
    burn = kpis.get("monthly_burn") or 0
    if runway is not None and runway < g.min_runway_months and burn > 0:
        target_burn = (kpis.get("cash_on_hand") or 0) / g.min_runway_months
        cut = max(0.0, burn - target_burn)
        drafts.append(
            Draft(
                dedupe_key="runway",
                kind="cash",
                title=f"Cash runway is {runway} months (floor: {g.min_runway_months:g})",
                reasoning=(
                    f"{_money(kpis.get('cash_on_hand') or 0, currency)} cash ÷ "
                    f"{_money(burn, currency)} monthly burn = {runway} months."
                ),
                recommendation=(
                    f"Cut monthly burn by about {_money(cut, currency)}, or bring in new cash, "
                    f"to get back to {g.min_runway_months:g} months."
                ),
                confidence=0.9,
                impact=f"Restores {g.min_runway_months:g}-month runway",
                task="Review costs and cash plan to restore runway",
            )
        )

    # 3. Margin falling
    cm_change = delta.get("contribution_margin_pct")
    if cm_change is not None and cm_change <= -2:
        drafts.append(
            Draft(
                dedupe_key=f"margin:{m.get('period')}",
                kind="margin",
                title=f"Contribution margin fell {abs(cm_change)} points",
                reasoning=(
                    f"Now {kpis.get('contribution_margin_pct')}%, down from "
                    f"{round((kpis.get('contribution_margin_pct') or 0) - cm_change, 2)}% "
                    f"in {m.get('previous_period')}."
                ),
                recommendation="Check which costs or returns rose; review prices on the lowest-margin products.",
                confidence=0.75,
                impact="Protects profit per order",
                task="Investigate margin drop (COGS, returns, discounts)",
            )
        )

    # 4. Customers leaving
    churn = kpis.get("churn_rate_pct")
    if churn is not None and churn > g.max_churn_pct:
        drafts.append(
            Draft(
                dedupe_key=f"churn:{m.get('period')}",
                kind="retention",
                title=f"Churn is {churn}% (limit: {g.max_churn_pct:g}%)",
                reasoning=f"{churn}% of customers were lost this period.",
                recommendation="Contact recently lost customers and run a win-back offer for at-risk ones.",
                confidence=0.7,
                impact="Keeps lifetime value from falling",
                task="Start win-back outreach to lost customers",
            )
        )

    # 5. Late shipments
    ships = service.shipments(db, business_id)
    late = [s for s in ships["items"] if s["status"] == "delayed"]
    if late:
        refs = ", ".join(s["reference"] for s in late[:5])
        drafts.append(
            Draft(
                dedupe_key="delayed:" + ",".join(sorted(s["reference"] for s in late))[:140],
                kind="fulfillment",
                title=f"{len(late)} shipment(s) delayed",
                reasoning=f"Past their promised ETA and not delivered: {refs}.",
                recommendation="Tell the affected customers now and chase the carriers for new ETAs.",
                confidence=0.85,
                impact="Protects on-time rate and customer trust",
                task=f"Notify customers + chase carriers for {refs}",
            )
        )

    # 6. Unpaid invoices piling up
    ar_pct = kpis.get("receivables_to_revenue_pct")
    if ar_pct is not None and ar_pct > 50:
        drafts.append(
            Draft(
                dedupe_key=f"receivables:{m.get('period')}",
                kind="cash",
                title=f"Receivables are {ar_pct}% of this period's sales",
                reasoning=f"{_money(kpis.get('accounts_receivable') or 0, currency)} is owed to you.",
                recommendation="Chase the largest overdue invoices first; tighten payment terms for repeat late payers.",
                confidence=0.75,
                impact="Brings cash in without new sales",
                task="Chase overdue invoices",
            )
        )

    return drafts


def _open_keys(db: Session, business_id: str) -> set[str]:
    stmt = select(Decision.dedupe_key).where(
        Decision.business_id == business_id, Decision.status == "pending"
    )
    return set(db.scalars(stmt))


def _make_task(db: Session, d: Decision, text: str | None) -> None:
    db.add(Task(business_id=d.business_id, decision_id=d.id, text=(text or d.title)[:400]))


def refresh(db: Session, business_id: str, *, actor: str, ip: str | None) -> list[Decision]:
    """Raise new decisions from the live model; returns the ones created."""
    g = service.get_guardrails(db, business_id)
    open_keys = _open_keys(db, business_id)
    created: list[Decision] = []
    for draft in draft_decisions(db, business_id):
        if draft.dedupe_key in open_keys:
            continue
        d = Decision(
            business_id=business_id,
            dedupe_key=draft.dedupe_key,
            kind=draft.kind,
            title=draft.title,
            reasoning=draft.reasoning,
            recommendation=draft.recommendation,
            confidence=draft.confidence,
            spend=draft.spend,
            impact=draft.impact,
            task_text=draft.task,
            source="rules",
        )
        db.add(d)
        db.flush()
        created.append(d)

        # Small reorders can clear themselves if the owner turned that on.
        if (
            draft.kind == "reorder"
            and g.auto_approve_limit > 0
            and draft.spend <= g.auto_approve_limit
            and draft.spend <= g.hard_spend_limit
        ):
            d.status = "approved"
            d.resolved_by = "auto"
            d.resolved_at = utcnow()
            d.resolution_note = f"Auto-approved: under the {g.auto_approve_limit:,.0f} auto limit"
            _make_task(db, d, draft.task)
            audit.record(db, business_id=business_id, actor="system", action="decision.auto_approve",
                         target=d.id, ip=ip, detail={"spend": d.spend})

    audit.record(db, business_id=business_id, actor=actor, action="decision.refresh",
                 ip=ip, detail={"created": len(created)})
    return created


def propose(
    db: Session,
    business_id: str,
    *,
    title: str,
    reasoning: str,
    recommendation: str,
    spend: float,
    confidence: float,
) -> Decision:
    """ELLA's only write path: add a *pending* decision for a human to judge."""
    g = service.get_guardrails(db, business_id)
    spend = max(0.0, min(float(spend), g.hard_spend_limit))
    confidence = max(0.0, min(float(confidence), 1.0))
    d = Decision(
        business_id=business_id,
        dedupe_key=f"ella:{title[:150]}",
        kind="suggestion",
        title=title[:240],
        reasoning=reasoning[:2000],
        recommendation=recommendation[:2000],
        confidence=confidence,
        spend=spend,
        impact="Suggested by ELLA — needs a human decision",
        source="ella",
        status="pending",
    )
    db.add(d)
    db.flush()
    audit.record(db, business_id=business_id, actor="ella", action="decision.propose",
                 target=d.id, detail={"spend": spend})
    return d


def _check_authority(role: str, spend: float, g) -> None:
    if ROLE_RANK.get(role, -1) < ROLE_RANK["operator"]:
        raise DecisionError(403, "forbidden", "Viewers can't resolve decisions.")
    if spend > g.hard_spend_limit:
        raise DecisionError(
            409, "over_hard_limit",
            f"Spend {spend:,.0f} is above the hard limit of {g.hard_spend_limit:,.0f}. "
            "An owner must raise the limit first.",
        )
    if role == "operator" and spend > g.operator_approval_limit:
        raise DecisionError(
            403, "needs_owner",
            f"Spend {spend:,.0f} is above the operator limit of {g.operator_approval_limit:,.0f}; "
            "an owner must approve it.",
        )


def _get_pending(db: Session, business_id: str, decision_id: str) -> Decision:
    d = db.get(Decision, decision_id)
    # Another business's decision looks exactly like a missing one.
    if d is None or d.business_id != business_id:
        raise DecisionError(404, "not_found", "Decision not found.")
    if d.status != "pending":
        raise DecisionError(409, "already_resolved", f"Decision is already {d.status}.")
    return d


def resolve(
    db: Session,
    business_id: str,
    decision_id: str,
    *,
    action: str,
    role: str,
    actor: str,
    ip: str | None,
    note: str | None = None,
    new_spend: float | None = None,
) -> Decision:
    g = service.get_guardrails(db, business_id)
    d = _get_pending(db, business_id, decision_id)

    if action == "dismiss":
        if ROLE_RANK.get(role, -1) < ROLE_RANK["operator"]:
            raise DecisionError(403, "forbidden", "Viewers can't resolve decisions.")
        d.status = "dismissed"
    elif action in ("approve", "adjust"):
        spend = d.spend if new_spend is None else float(new_spend)
        _check_authority(role, spend, g)
        before = d.spend
        d.spend = spend
        d.status = "approved" if action == "approve" else "adjusted"
        base = d.task_text or d.title
        task_text = base if action == "approve" else f"{base} (adjusted: {note})"
        if action == "adjust" and spend != before:
            task_text += f" — spend {spend:,.0f}"
        _make_task(db, d, task_text)
    else:
        raise DecisionError(400, "bad_action", "Unknown action.")

    d.resolved_by = actor
    d.resolved_at = utcnow()
    d.resolution_note = note
    audit.record(db, business_id=business_id, actor=actor, action=f"decision.{action}",
                 target=d.id, ip=ip, detail={"spend": d.spend, "role": role})
    return d


def to_dict(d: Decision) -> dict[str, Any]:
    return {
        "id": d.id,
        "kind": d.kind,
        "title": d.title,
        "reasoning": d.reasoning,
        "recommendation": d.recommendation,
        "confidence_pct": round(d.confidence * 100),
        "spend": d.spend,
        "impact": d.impact,
        "source": d.source,
        "status": d.status,
        "resolved_by": d.resolved_by,
        "note": d.resolution_note,
        "created_at": d.created_at.isoformat() if d.created_at else None,
        "resolved_at": d.resolved_at.isoformat() if d.resolved_at else None,
    }
