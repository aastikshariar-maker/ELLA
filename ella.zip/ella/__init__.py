"""ELLA — the AI operator inside Core.

See ella/README.md for setup, the API and the security model.
"""

__version__ = "1.0.0"
