"""ELLA's HTTP API.

Run:  uvicorn ella.main:app --host 127.0.0.1 --port 8100

Every route except /health needs ``Authorization: Bearer ella_...``.
There is deliberately no sign-up endpoint: businesses and their first owner
key are created from the command line (``python -m ella create-business``),
so nobody on the internet can create accounts.
"""

from __future__ import annotations

import logging
from typing import Any, Callable, Iterator

from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy import delete, select
from sqlalchemy.orm import Session
from starlette.exceptions import HTTPException as StarletteHTTPException

from . import audit, decisions, service
from .agent import Ella
from .config import Settings, load_settings
from .models import ApiKey, AuditEvent, Business, Decision, Shipment, Sku, Snapshot, Task, make_session_factory
from .schemas import (
    ChatIn,
    DecisionAction,
    DecisionAdjust,
    GuardrailsIn,
    KeyIn,
    ShipmentBatch,
    SkuBatch,
    SnapshotIn,
    TaskIn,
    TaskUpdate,
)
from .security import HardeningMiddleware, Principal, RateLimiter, authenticate, client_ip, create_api_key

log = logging.getLogger("ella.api")


def create_app(settings: Settings | None = None, llm_client: Any | None = None) -> FastAPI:
    settings = settings or load_settings()
    SessionLocal = make_session_factory(settings.database_url)
    limiter = RateLimiter()
    ella = Ella(settings, client=llm_client)

    app = FastAPI(
        title="ELLA — Core's AI operator",
        version="1.0.0",
        # No public API explorer in production.
        docs_url=None if settings.is_production else "/docs",
        redoc_url=None,
        openapi_url=None if settings.is_production else "/openapi.json",
    )
    app.state.settings = settings
    app.state.limiter = limiter
    app.state.session_factory = SessionLocal

    app.add_middleware(HardeningMiddleware, max_body_bytes=settings.max_body_bytes, hsts=settings.is_production)
    if settings.cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=settings.cors_origins,  # explicit list only, never "*"
            allow_credentials=False,
            allow_methods=["GET", "POST", "PUT", "PATCH", "DELETE"],
            allow_headers=["Authorization", "Content-Type"],
            max_age=600,
        )

    # ---------- errors: short, consistent, never a stack trace ----------

    @app.exception_handler(StarletteHTTPException)
    async def http_error(_: Request, exc: StarletteHTTPException):
        detail = exc.detail if isinstance(exc.detail, dict) else {"error": str(exc.detail)}
        return JSONResponse(detail, status_code=exc.status_code, headers=getattr(exc, "headers", None))

    @app.exception_handler(RequestValidationError)
    async def validation_error(_: Request, exc: RequestValidationError):
        problems = [
            {"field": ".".join(str(p) for p in e.get("loc", [])[1:]), "problem": e.get("msg", "invalid")}
            for e in exc.errors()[:20]
        ]
        return JSONResponse({"error": "invalid_request", "problems": problems}, status_code=422)

    @app.exception_handler(Exception)
    async def unexpected(_: Request, exc: Exception):
        log.exception("unhandled error")
        return JSONResponse({"error": "internal_error"}, status_code=500)

    # ---------- dependencies ----------

    def get_db() -> Iterator[Session]:
        db = SessionLocal()
        try:
            yield db
            db.commit()
        except Exception:
            db.rollback()
            raise
        finally:
            db.close()

    def principal(request: Request, db: Session = Depends(get_db)) -> Principal:
        ip = client_ip(request)
        if limiter.count(f"authfail:{ip}") >= settings.auth_failures_per_minute:
            raise HTTPException(429, {"error": "too_many_attempts"}, headers={"Retry-After": "60"})
        p = authenticate(db, request.headers.get("authorization"), settings.key_pepper)
        if p is None:
            limiter.allow(f"authfail:{ip}", 10**9)
            # Logged without a business (we don't know one) and without the key.
            db.rollback()
            audit.record(db, business_id=None, actor="anonymous", action="auth.failed", ip=ip,
                         detail={"path": request.url.path[:120]})
            db.commit()
            raise HTTPException(401, {"error": "unauthorized"}, headers={"WWW-Authenticate": "Bearer"})
        ok, retry = limiter.allow(f"key:{p.key_id}", settings.rate_limit_per_minute)
        if not ok:
            raise HTTPException(429, {"error": "rate_limited"}, headers={"Retry-After": str(retry)})
        request.state.principal = p
        return p

    def require(role: str) -> Callable[..., Principal]:
        def dep(p: Principal = Depends(principal)) -> Principal:
            if not p.at_least(role):
                raise HTTPException(403, {"error": "forbidden", "needs_role": role})
            return p
        return dep

    viewer, operator, owner = require("viewer"), require("operator"), require("owner")

    def ip_of(request: Request) -> str:
        return client_ip(request)

    # ---------- health ----------

    @app.get("/health")
    def health():
        return {"status": "ok", "ella": "online" if ella.online else "offline-mode"}

    # ---------- the live model ----------

    @app.get("/v1/metrics")
    def get_metrics(p: Principal = Depends(viewer), db: Session = Depends(get_db)):
        return service.metrics(db, p.business_id)

    @app.get("/v1/inventory")
    def get_inventory(p: Principal = Depends(viewer), db: Session = Depends(get_db)):
        return service.inventory(db, p.business_id)

    @app.get("/v1/shipments")
    def get_shipments(p: Principal = Depends(viewer), db: Session = Depends(get_db)):
        return service.shipments(db, p.business_id)

    @app.put("/v1/data/snapshot", status_code=201)
    def put_snapshot(body: SnapshotIn, request: Request, p: Principal = Depends(operator), db: Session = Depends(get_db)):
        data = body.model_dump()
        label = data.pop("period_label")
        snap = Snapshot(business_id=p.business_id, period_label=label, data=data)
        db.add(snap)
        db.flush()
        audit.record(db, business_id=p.business_id, actor=p.actor, action="data.snapshot", target=snap.id, ip=ip_of(request))
        created = decisions.refresh(db, p.business_id, actor=p.actor, ip=ip_of(request))
        return {"snapshot_id": snap.id, "metrics": service.metrics(db, p.business_id),
                "new_decisions": [decisions.to_dict(d) for d in created]}

    @app.put("/v1/data/skus")
    def put_skus(body: SkuBatch, request: Request, p: Principal = Depends(operator), db: Session = Depends(get_db)):
        codes = [i.code for i in body.items]
        if len(codes) != len(set(codes)):
            raise HTTPException(422, {"error": "duplicate_sku_codes"})
        existing = {s.code: s for s in db.scalars(select(Sku).where(Sku.business_id == p.business_id))}
        for item in body.items:
            row = existing.get(item.code) or Sku(business_id=p.business_id, code=item.code)
            for k, v in item.model_dump().items():
                setattr(row, k, v)
            db.add(row)
        removed = 0
        if body.replace:
            gone = set(existing) - set(codes)
            if gone:
                removed = db.execute(delete(Sku).where(Sku.business_id == p.business_id, Sku.code.in_(gone))).rowcount
        db.flush()
        audit.record(db, business_id=p.business_id, actor=p.actor, action="data.skus", ip=ip_of(request),
                     detail={"upserted": len(codes), "removed": removed})
        created = decisions.refresh(db, p.business_id, actor=p.actor, ip=ip_of(request))
        return {"upserted": len(codes), "removed": removed, "inventory": service.inventory(db, p.business_id),
                "new_decisions": [decisions.to_dict(d) for d in created]}

    @app.put("/v1/data/shipments")
    def put_shipments(body: ShipmentBatch, request: Request, p: Principal = Depends(operator), db: Session = Depends(get_db)):
        refs = [i.reference for i in body.items]
        if len(refs) != len(set(refs)):
            raise HTTPException(422, {"error": "duplicate_shipment_references"})
        existing = {s.reference: s for s in db.scalars(select(Shipment).where(Shipment.business_id == p.business_id))}
        for item in body.items:
            row = existing.get(item.reference) or Shipment(business_id=p.business_id, reference=item.reference)
            for k, v in item.model_dump().items():
                setattr(row, k, v)
            db.add(row)
        removed = 0
        if body.replace:
            gone = set(existing) - set(refs)
            if gone:
                removed = db.execute(delete(Shipment).where(Shipment.business_id == p.business_id, Shipment.reference.in_(gone))).rowcount
        db.flush()
        audit.record(db, business_id=p.business_id, actor=p.actor, action="data.shipments", ip=ip_of(request),
                     detail={"upserted": len(refs), "removed": removed})
        created = decisions.refresh(db, p.business_id, actor=p.actor, ip=ip_of(request))
        return {"upserted": len(refs), "removed": removed, "shipments": service.shipments(db, p.business_id),
                "new_decisions": [decisions.to_dict(d) for d in created]}

    # ---------- decisions ----------

    @app.get("/v1/decisions")
    def list_decisions(status: str = "pending", p: Principal = Depends(viewer), db: Session = Depends(get_db)):
        if status not in ("pending", "approved", "adjusted", "dismissed", "all"):
            raise HTTPException(422, {"error": "bad_status"})
        stmt = select(Decision).where(Decision.business_id == p.business_id)
        if status != "all":
            stmt = stmt.where(Decision.status == status)
        rows = db.scalars(stmt.order_by(Decision.created_at.desc()).limit(200))
        return [decisions.to_dict(d) for d in rows]

    @app.post("/v1/decisions/refresh")
    def refresh_decisions(request: Request, p: Principal = Depends(operator), db: Session = Depends(get_db)):
        created = decisions.refresh(db, p.business_id, actor=p.actor, ip=ip_of(request))
        return [decisions.to_dict(d) for d in created]

    def _resolve(db: Session, p: Principal, request: Request, decision_id: str, action: str,
                 note: str | None, spend: float | None = None):
        try:
            d = decisions.resolve(db, p.business_id, decision_id, action=action, role=p.role,
                                  actor=p.actor, ip=ip_of(request), note=note, new_spend=spend)
        except decisions.DecisionError as e:
            # Record refused attempts too — they matter most in an audit.
            # Undo any partial work from this request first, then log and commit.
            db.rollback()
            audit.record(db, business_id=p.business_id, actor=p.actor, action=f"decision.{action}.refused",
                         target=decision_id[:64], ip=ip_of(request), detail={"reason": e.code})
            db.commit()
            raise HTTPException(e.status, {"error": e.code, "message": e.message})
        return decisions.to_dict(d)

    @app.post("/v1/decisions/{decision_id}/approve")
    def approve(decision_id: str, body: DecisionAction, request: Request, p: Principal = Depends(operator), db: Session = Depends(get_db)):
        return _resolve(db, p, request, decision_id, "approve", body.note)

    @app.post("/v1/decisions/{decision_id}/adjust")
    def adjust(decision_id: str, body: DecisionAdjust, request: Request, p: Principal = Depends(operator), db: Session = Depends(get_db)):
        return _resolve(db, p, request, decision_id, "adjust", body.note, body.spend)

    @app.post("/v1/decisions/{decision_id}/dismiss")
    def dismiss(decision_id: str, body: DecisionAction, request: Request, p: Principal = Depends(operator), db: Session = Depends(get_db)):
        return _resolve(db, p, request, decision_id, "dismiss", body.note)

    # ---------- tasks ----------

    def _task_dict(t: Task) -> dict[str, Any]:
        return {"id": t.id, "text": t.text, "assignee": t.assignee, "done": t.done,
                "decision_id": t.decision_id, "created_at": t.created_at.isoformat()}

    @app.get("/v1/tasks")
    def list_tasks(p: Principal = Depends(viewer), db: Session = Depends(get_db)):
        rows = db.scalars(select(Task).where(Task.business_id == p.business_id).order_by(Task.created_at.desc()).limit(500))
        return [_task_dict(t) for t in rows]

    @app.post("/v1/tasks", status_code=201)
    def add_task(body: TaskIn, request: Request, p: Principal = Depends(operator), db: Session = Depends(get_db)):
        t = Task(business_id=p.business_id, text=body.text, assignee=body.assignee)
        db.add(t)
        db.flush()
        audit.record(db, business_id=p.business_id, actor=p.actor, action="task.create", target=t.id, ip=ip_of(request))
        return _task_dict(t)

    @app.patch("/v1/tasks/{task_id}")
    def update_task(task_id: str, body: TaskUpdate, request: Request, p: Principal = Depends(operator), db: Session = Depends(get_db)):
        t = db.get(Task, task_id)
        if t is None or t.business_id != p.business_id:
            raise HTTPException(404, {"error": "not_found"})
        if body.done is not None:
            t.done = body.done
        if body.assignee is not None:
            t.assignee = body.assignee
        audit.record(db, business_id=p.business_id, actor=p.actor, action="task.update", target=t.id, ip=ip_of(request))
        return _task_dict(t)

    # ---------- guardrails ----------

    @app.get("/v1/guardrails")
    def get_guardrails(p: Principal = Depends(viewer), db: Session = Depends(get_db)):
        return service.guardrails_dict(service.get_guardrails(db, p.business_id))

    @app.put("/v1/guardrails")
    def put_guardrails(body: GuardrailsIn, request: Request, p: Principal = Depends(owner), db: Session = Depends(get_db)):
        g = service.get_guardrails(db, p.business_id)
        before = service.guardrails_dict(g)
        changes = body.model_dump(exclude_none=True)
        for k, v in changes.items():
            setattr(g, k, v)
        if g.operator_approval_limit > g.hard_spend_limit or g.auto_approve_limit > g.hard_spend_limit:
            raise HTTPException(422, {"error": "limits_inconsistent",
                                      "message": "Operator and auto-approve limits can't exceed the hard limit."})
        audit.record(db, business_id=p.business_id, actor=p.actor, action="guardrails.update", ip=ip_of(request),
                     detail={"before": {k: before[k] for k in changes}, "after": changes})
        return service.guardrails_dict(g)

    # ---------- ELLA ----------

    @app.post("/v1/ella/chat")
    def chat(body: ChatIn, request: Request, p: Principal = Depends(viewer), db: Session = Depends(get_db)):
        ok, retry = limiter.allow(f"chat:{p.business_id}", settings.chat_rate_limit_per_minute)
        if not ok:
            raise HTTPException(429, {"error": "rate_limited"}, headers={"Retry-After": str(retry)})
        business = db.get(Business, p.business_id)
        try:
            result = ella.respond(
                db, p.business_id, business.name, business.currency, body.message,
                [h.model_dump() for h in body.history], channel=body.channel,
            )
        except Exception:
            log.exception("ELLA failed")
            raise HTTPException(503, {"error": "ella_unavailable",
                                      "message": "ELLA couldn't answer right now. Try again shortly."})
        # Message text is not stored — only that a chat happened.
        audit.record(db, business_id=p.business_id, actor=p.actor, action=f"ella.{body.channel}", ip=ip_of(request),
                     detail={"chars": len(body.message), "tools": result.tools_used, "mode": result.mode,
                             "proposed": result.proposed_decisions})
        return {"reply": result.reply, "mode": result.mode, "tools_used": result.tools_used,
                "proposed_decisions": result.proposed_decisions}

    # ---------- keys & audit (owners only) ----------

    @app.get("/v1/keys")
    def list_keys(p: Principal = Depends(owner), db: Session = Depends(get_db)):
        rows = db.scalars(select(ApiKey).where(ApiKey.business_id == p.business_id).order_by(ApiKey.created_at))
        return [{"id": k.id, "name": k.name, "role": k.role, "prefix": k.prefix, "revoked": k.revoked,
                 "created_at": k.created_at.isoformat(),
                 "expires_at": k.expires_at.isoformat() if k.expires_at else None,
                 "last_used_at": k.last_used_at.isoformat() if k.last_used_at else None} for k in rows]

    @app.post("/v1/keys", status_code=201)
    def make_key(body: KeyIn, request: Request, p: Principal = Depends(owner), db: Session = Depends(get_db)):
        row, plain = create_api_key(db, business_id=p.business_id, name=body.name, role=body.role,
                                    pepper=settings.key_pepper, expires_in_days=body.expires_in_days)
        audit.record(db, business_id=p.business_id, actor=p.actor, action="key.create", target=row.id,
                     ip=ip_of(request), detail={"role": body.role, "prefix": row.prefix})
        return {"id": row.id, "key": plain, "role": row.role,
                "warning": "Store this key now. It can't be shown again."}

    @app.delete("/v1/keys/{key_id}")
    def revoke_key(key_id: str, request: Request, p: Principal = Depends(owner), db: Session = Depends(get_db)):
        row = db.get(ApiKey, key_id)
        if row is None or row.business_id != p.business_id:
            raise HTTPException(404, {"error": "not_found"})
        if row.id == p.key_id:
            raise HTTPException(409, {"error": "cannot_revoke_own_key",
                                      "message": "Use a different owner key to revoke this one."})
        row.revoked = True
        audit.record(db, business_id=p.business_id, actor=p.actor, action="key.revoke", target=row.id, ip=ip_of(request))
        return {"revoked": True}

    @app.get("/v1/audit")
    def get_audit(limit: int = 100, p: Principal = Depends(owner), db: Session = Depends(get_db)):
        limit = max(1, min(limit, 500))
        rows = db.scalars(select(AuditEvent).where(AuditEvent.business_id == p.business_id)
                          .order_by(AuditEvent.id.desc()).limit(limit))
        return [{"at": e.at.isoformat(), "actor": e.actor, "action": e.action, "target": e.target,
                 "ip": e.ip, "detail": e.detail} for e in rows]

    return app
