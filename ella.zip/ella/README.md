# ELLA — the AI operator inside Core

ELLA is Core's AI. She reads a live model of the business (sales, margins, cash,
stock, shipments, customers), raises decisions with the reasoning attached,
answers the team's questions in plain language, and answers the phone as the
receptionist — without ever being able to spend money on her own.

This folder is self-contained: it doesn't use the older `app/` code.

## What she does

| Part | What it does |
|---|---|
| **Live model** (`calc.py`) | Recalculates ~20 KPIs from your numbers: net profit, gross / contribution / operating margin, burn, cash runway, on-time fulfillment, CAC, LTV, churn, receivables, break-even. Exact math, no AI, unit-tested. |
| **Inventory** | Days of supply per SKU vs supplier lead time → `critical` (runs out before a reorder arrives), `low` (inside the safety buffer) or `healthy`. |
| **Shipments** | Anything past its ETA and not delivered counts as delayed. |
| **Decisions queue** (`decisions.py`) | Raises: reorders (with quantity and cost), runway below your floor, margin drops, high churn, late shipments, unpaid invoices piling up. Each has reasoning, confidence and spend. People approve, adjust or dismiss; approvals become tasks. |
| **Chat** (`agent.py`) | Ask anything about the business. Every number comes from a tool that calls the live model. She can run what-if scenarios ("what if we cut opex 15%?") and queue suggestions for approval. |
| **Receptionist** | Same ELLA, public-facing mode: checks an order's status by reference, and shares nothing internal. |
| **Offline mode** | With no `ANTHROPIC_API_KEY`, she still answers the common questions (runway, margin, stock, shipments, customers, decisions) straight from the numbers. |

## Run it

```bash
pip install -r ella/requirements.txt

export ELLA_KEY_PEPPER="$(python -c 'import secrets;print(secrets.token_urlsafe(48))')"   # keep this safe
export ANTHROPIC_API_KEY=...          # optional; offline mode without it

python -m ella create-business "Anka Retail" --currency BDT   # prints business id + owner key (once)
python -m ella load-demo <business_id>                          # optional sample data

uvicorn ella.main:app --host 127.0.0.1 --port 8100 --no-server-header
```

Try it:

```bash
curl -s localhost:8100/v1/ella/chat -H "Authorization: Bearer ella_..." \
  -H "content-type: application/json" -d '{"message":"any stock risk this week?"}'
```

Run the tests: `pytest ella/tests`

## API

All routes need `Authorization: Bearer ella_...` except `/health`.

| Method & path | Role | Purpose |
|---|---|---|
| `GET /v1/metrics` | viewer | Live KPIs + change vs previous period |
| `GET /v1/inventory` · `GET /v1/shipments` | viewer | Stock and shipment status |
| `PUT /v1/data/snapshot` | operator | Upload a period's numbers (recalculates + raises decisions) |
| `PUT /v1/data/skus` · `PUT /v1/data/shipments` | operator | Upsert stock / shipments (`replace: true` removes unlisted) |
| `GET /v1/decisions?status=pending` | viewer | The queue |
| `POST /v1/decisions/{id}/approve` · `/adjust` · `/dismiss` | operator | Resolve (spending limits apply) |
| `POST /v1/decisions/refresh` | operator | Re-check the model for new decisions |
| `GET /v1/tasks` · `POST /v1/tasks` · `PATCH /v1/tasks/{id}` | viewer / operator | Tasks from approved decisions |
| `GET/PUT /v1/guardrails` | viewer / owner | Spending limits and thresholds |
| `POST /v1/ella/chat` | viewer | `{"message", "history"?, "channel": "chat" or "receptionist"}` |
| `GET/POST /v1/keys` · `DELETE /v1/keys/{id}` | owner | Manage API keys |
| `GET /v1/audit` | owner | Who did what |

In development, interactive docs are at `/docs` (switched off in production).

## Security model

**Accounts and keys**
- No sign-up endpoint. Businesses are created on the server with the CLI, so nobody on the internet can make an account.
- Keys are 256-bit random, shown once, stored only as `HMAC-SHA256(pepper, key)`. The pepper is an environment variable, so a stolen database can't be used to test guessed keys.
- Three roles: **viewer** (read), **operator** (upload data, resolve decisions within limits), **owner** (keys, guardrails, audit, big approvals). Operators can't create owner keys.
- Keys expire (default 1 year) and can be revoked; an owner can't revoke the key they're using, so they can't lock themselves out by accident.

**Isolation**
- Every query filters by the business the key belongs to. Another business's decision returns the same `404` as a made-up id, so ids can't be probed.

**Money**
- Spending limits are enforced in server code, never by the AI: operators up to `operator_approval_limit`, owners up to `hard_spend_limit`, nothing above that until an owner raises it. Limits that don't make sense (operator > hard) are rejected.
- Optional auto-approval applies to small **reorders only**.

**ELLA herself**
- Her only write is `propose_decision` → always `pending`, spend clamped to the hard limit, max 3 per message. There is no tool that approves, pays or changes anything.
- The receptionist gets one tool (shipment status) and never sees finances — even if a caller tells her to ignore her rules, the tools simply aren't there. Customers see status and date only, not freight cost or origin.
- Tool output goes back as JSON data and she's told to treat text in it as data, not instructions.
- Bounded: step limit, token limit, 20-turn history, 4,000-character messages, 30-second timeout. If Claude is down, the API returns a clean `503`.

**HTTP**
- Rate limits per key, per business for chat, and per IP for failed logins (brute force gets `429`).
- Body size cap, strict validation (unknown fields rejected, numbers bounded, control characters stripped).
- Security headers on every response (`nosniff`, `DENY` framing, strict CSP, `no-store`), HSTS in production, CORS only for origins you list.
- Errors never include stack traces or internal messages.

**Audit**
- Data uploads, approvals (and refused approvals), guardrail changes, key changes, failed logins and chats are logged with actor and IP. Chat **text** is not stored — only that a chat happened, its length and which tools ran.

### Deploying safely
1. Put ELLA behind HTTPS (e.g. Caddy or Nginx). Run uvicorn on `127.0.0.1`, with `--proxy-headers --forwarded-allow-ips=<proxy ip>` so rate limits see real client IPs.
2. Set `ELLA_ENV=production` and a strong `ELLA_KEY_PEPPER`; keep both out of git.
3. The Core website should call ELLA from its own server, not from the browser, so keys never reach visitors. If the browser must call it, set `ELLA_CORS_ORIGINS` to the site's exact origin and use a **viewer** key.
4. Rate limits are per process. With several processes, add the same limits at the proxy.
5. Back up the database; rotate keys if a laptop or server is lost (`python -m ella revoke-key <id>`).
