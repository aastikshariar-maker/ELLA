"""Audit trail: who did what, when, from where."""

from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from .models import AuditEvent


def record(
    db: Session,
    *,
    business_id: str | None,
    actor: str,
    action: str,
    target: str | None = None,
    ip: str | None = None,
    detail: dict[str, Any] | None = None,
) -> None:
    db.add(
        AuditEvent(
            business_id=business_id,
            actor=actor[:32],
            action=action[:48],
            target=(target or None) and target[:64],
            ip=(ip or None) and ip[:64],
            detail=detail or {},
        )
    )
