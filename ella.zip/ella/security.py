"""Authentication, roles, rate limiting and HTTP hardening.

How API keys work
-----------------
* A key looks like ``ella_<43 random chars>`` (256 bits from ``secrets``).
* It is shown exactly once, when created. ELLA stores only
  ``HMAC-SHA256(pepper, key)``; the pepper lives in the environment, not the
  database, so a leaked database can't be used to check guessed keys.
* Keys belong to one business and one role, can expire, and can be revoked.
"""

from __future__ import annotations

import hashlib
import hmac
import secrets
import threading
import time
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from fastapi import Request
from sqlalchemy import select
from sqlalchemy.orm import Session
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from .models import ApiKey, utcnow

KEY_PREFIX = "ella_"
ROLE_RANK = {"viewer": 0, "operator": 1, "owner": 2}


def generate_key() -> str:
    return KEY_PREFIX + secrets.token_urlsafe(32)


def hash_key(key: str, pepper: str) -> str:
    return hmac.new(pepper.encode(), key.encode(), hashlib.sha256).hexdigest()


def create_api_key(
    db: Session,
    *,
    business_id: str,
    name: str,
    role: str,
    pepper: str,
    expires_in_days: int | None = 365,
) -> tuple[ApiKey, str]:
    """Returns the stored row and the plain key (the only time it exists)."""
    if role not in ROLE_RANK:
        raise ValueError("bad role")
    plain = generate_key()
    row = ApiKey(
        business_id=business_id,
        name=name,
        role=role,
        prefix=plain[:12],
        key_hash=hash_key(plain, pepper),
        expires_at=(utcnow() + timedelta(days=expires_in_days)) if expires_in_days else None,
    )
    db.add(row)
    db.flush()
    return row, plain


@dataclass(frozen=True)
class Principal:
    key_id: str
    business_id: str
    role: str
    actor: str  # key prefix — safe to log, useless to an attacker

    def at_least(self, role: str) -> bool:
        return ROLE_RANK[self.role] >= ROLE_RANK[role]


def _aware(dt: datetime | None) -> datetime | None:
    if dt is None:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def authenticate(db: Session, raw_header: str | None, pepper: str) -> Principal | None:
    if not raw_header:
        return None
    scheme, _, token = raw_header.partition(" ")
    if scheme.lower() != "bearer" or not token.startswith(KEY_PREFIX) or len(token) > 100:
        return None
    digest = hash_key(token.strip(), pepper)
    row = db.scalar(select(ApiKey).where(ApiKey.key_hash == digest))
    # Lookup is by hash, then re-compared in constant time.
    if row is None or not hmac.compare_digest(row.key_hash, digest):
        return None
    if row.revoked:
        return None
    expires = _aware(row.expires_at)
    if expires is not None and expires <= utcnow():
        return None
    row.last_used_at = utcnow()
    return Principal(key_id=row.id, business_id=row.business_id, role=row.role, actor=row.prefix)


class RateLimiter:
    """Sliding one-minute window per bucket.

    In memory, so it is per process. If ELLA runs as several processes behind
    a load balancer, put the same limits on the proxy (or swap this for Redis).
    """

    def __init__(self) -> None:
        self._hits: dict[str, deque[float]] = defaultdict(deque)
        self._lock = threading.Lock()

    def allow(self, bucket: str, limit: int, window: float = 60.0) -> tuple[bool, int]:
        now = time.monotonic()
        with self._lock:
            q = self._hits[bucket]
            while q and q[0] <= now - window:
                q.popleft()
            if len(q) >= limit:
                retry = int(window - (now - q[0])) + 1
                return False, retry
            q.append(now)
            if len(self._hits) > 50_000:  # don't let junk buckets eat memory
                for k in [k for k, v in self._hits.items() if not v][:10_000]:
                    del self._hits[k]
            return True, 0

    def count(self, bucket: str, window: float = 60.0) -> int:
        now = time.monotonic()
        with self._lock:
            q = self._hits.get(bucket)
            if not q:
                return 0
            while q and q[0] <= now - window:
                q.popleft()
            return len(q)

    def reset(self) -> None:
        with self._lock:
            self._hits.clear()


def client_ip(request: Request) -> str:
    # Uses the direct peer address. If ELLA sits behind a trusted reverse
    # proxy, run uvicorn with --proxy-headers --forwarded-allow-ips=<proxy ip>
    # so this becomes the real client address. Never trust X-Forwarded-For
    # from the open internet.
    return request.client.host if request.client else "unknown"


SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "Referrer-Policy": "no-referrer",
    "Cross-Origin-Opener-Policy": "same-origin",
    "Cross-Origin-Resource-Policy": "same-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
    "Cache-Control": "no-store",
}
# The interactive docs page needs scripts and styles from a CDN; every other
# response is JSON and gets the strictest policy.
API_CSP = "default-src 'none'; frame-ancestors 'none'"


class HardeningMiddleware(BaseHTTPMiddleware):
    def __init__(self, app, *, max_body_bytes: int, hsts: bool):
        super().__init__(app)
        self.max_body_bytes = max_body_bytes
        self.hsts = hsts

    async def dispatch(self, request: Request, call_next):
        length = request.headers.get("content-length")
        if length is not None:
            try:
                too_big = int(length) > self.max_body_bytes
            except ValueError:
                return JSONResponse({"error": "bad_request"}, status_code=400)
            if too_big:
                return JSONResponse({"error": "payload_too_large"}, status_code=413)
        elif request.method in ("POST", "PUT", "PATCH"):
            body = await request.body()
            if len(body) > self.max_body_bytes:
                return JSONResponse({"error": "payload_too_large"}, status_code=413)

        response = await call_next(request)
        for name, value in SECURITY_HEADERS.items():
            response.headers.setdefault(name, value)
        if not request.url.path.startswith(("/docs", "/openapi.json")):
            response.headers.setdefault("Content-Security-Policy", API_CSP)
        if self.hsts:
            response.headers.setdefault("Strict-Transport-Security", "max-age=63072000; includeSubDomains")
        response.headers["Server"] = "ella"
        return response
