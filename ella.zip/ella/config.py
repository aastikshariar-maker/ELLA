"""ELLA configuration.

Every setting comes from environment variables (or a .env file loaded by the
process manager). Nothing secret has a usable default: in production ELLA
refuses to start without the secrets it needs.
"""

from __future__ import annotations

import os
import secrets
import warnings
from dataclasses import dataclass, field


def _env(name: str, default: str | None = None) -> str | None:
    value = os.getenv(name)
    if value is None or value.strip() == "":
        return default
    return value.strip()


def _env_int(name: str, default: int) -> int:
    raw = _env(name)
    if raw is None:
        return default
    try:
        return int(raw)
    except ValueError as exc:
        raise RuntimeError(f"{name} must be an integer") from exc


def _env_list(name: str) -> list[str]:
    raw = _env(name, "")
    return [item.strip() for item in raw.split(",") if item.strip()]


@dataclass(frozen=True)
class Settings:
    environment: str = "development"
    database_url: str = "sqlite:///./ella.db"

    # Pepper mixed into every API-key hash. A stolen database alone is then
    # not enough to verify guessed keys.
    key_pepper: str = ""

    # Claude (the model ELLA thinks with). Without a key ELLA still answers
    # from the live numbers in offline mode.
    anthropic_api_key: str | None = None
    model: str = "claude-sonnet-5-5"
    llm_timeout_seconds: int = 30
    llm_max_tokens: int = 1024
    agent_max_steps: int = 6

    # Abuse limits
    rate_limit_per_minute: int = 120
    chat_rate_limit_per_minute: int = 15
    auth_failures_per_minute: int = 20
    max_body_bytes: int = 512 * 1024

    cors_origins: list[str] = field(default_factory=list)

    @property
    def is_production(self) -> bool:
        return self.environment == "production"


def load_settings() -> Settings:
    environment = (_env("ELLA_ENV", "development") or "development").lower()
    pepper = _env("ELLA_KEY_PEPPER")

    if pepper is None:
        if environment == "production":
            raise RuntimeError(
                "ELLA_KEY_PEPPER must be set in production "
                "(generate one with: python -c \"import secrets;print(secrets.token_urlsafe(48))\")"
            )
        # Development only: random per process, so keys made in one run will
        # not work after a restart. That is deliberate — it forces a real
        # pepper to be configured before anything is relied on.
        pepper = secrets.token_urlsafe(48)
        warnings.warn(
            "ELLA_KEY_PEPPER not set; using a temporary one. API keys will stop "
            "working when the process restarts.",
            RuntimeWarning,
            stacklevel=2,
        )
    elif len(pepper) < 32:
        raise RuntimeError("ELLA_KEY_PEPPER must be at least 32 characters")

    return Settings(
        environment=environment,
        database_url=_env("ELLA_DATABASE_URL", "sqlite:///./ella.db") or "sqlite:///./ella.db",
        key_pepper=pepper,
        anthropic_api_key=_env("ANTHROPIC_API_KEY"),
        model=_env("ELLA_MODEL", "claude-sonnet-5-5") or "claude-sonnet-5-5",
        llm_timeout_seconds=_env_int("ELLA_LLM_TIMEOUT_SECONDS", 30),
        llm_max_tokens=_env_int("ELLA_LLM_MAX_TOKENS", 1024),
        agent_max_steps=_env_int("ELLA_AGENT_MAX_STEPS", 6),
        rate_limit_per_minute=_env_int("ELLA_RATE_LIMIT_PER_MINUTE", 120),
        chat_rate_limit_per_minute=_env_int("ELLA_CHAT_RATE_LIMIT_PER_MINUTE", 15),
        auth_failures_per_minute=_env_int("ELLA_AUTH_FAILURES_PER_MINUTE", 20),
        max_body_bytes=_env_int("ELLA_MAX_BODY_BYTES", 512 * 1024),
        cors_origins=_env_list("ELLA_CORS_ORIGINS"),
    )
